"""
My name is vedant nimkar and I am doing programing in python for the first time
This is just to check what the inverted comma does in the python programing language
"""
num1 = float(input("Enter the first number: "))
num2 = float(input("Enter the second number: "))
#this is a program to add 2 numbers
sum = num1 + num2
SUM1 = 2 + 4
SUM2 = 6
print("sum of 2nd one is ",SUM1)
print("The sum of", num1, "and", num2, "is", sum)
print("the multiplication of the two numbers is ", num1 * num2)
print("the Division of the two numbers is ", num1 / num2)
print("the Substraction of the two numbers is ", num1 - num2)

def SUMAF():
    X=25
    print("Value of x is ", X)
SUMAF()

print("the value for the sum of SUM1 and SUM2 is ", SUM1+SUM2 )
