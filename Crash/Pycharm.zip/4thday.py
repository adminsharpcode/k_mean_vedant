counter = 0
i = 0.0
while counter != 10:
    i=i+counter
    i=i%10
    print(i)
    counter = counter +1




